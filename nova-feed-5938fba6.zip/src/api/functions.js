import { base44 } from './base44Client';


export const sendTelegramNotification = base44.functions.sendTelegramNotification;

export const checkAppUpdates = base44.functions.checkAppUpdates;

export const cleanupOldNews = base44.functions.cleanupOldNews;

export const advancedNewsMonitor = base44.functions.advancedNewsMonitor;

export const realTimeNewsMonitor = base44.functions.realTimeNewsMonitor;

export const masterNewsSystem = base44.functions.masterNewsSystem;

