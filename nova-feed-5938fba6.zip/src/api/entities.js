import { base44 } from './base44Client';


export const NewsArticle = base44.entities.NewsArticle;

export const Notification = base44.entities.Notification;

export const AITool = base44.entities.AITool;



// auth sdk:
export const User = base44.auth;