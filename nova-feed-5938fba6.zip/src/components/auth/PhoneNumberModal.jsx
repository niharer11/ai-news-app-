import React, { useState } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Smartphone, Save } from "lucide-react";

export default function PhoneNumberModal({ onComplete }) {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    if (phoneNumber.length < 10) {
      setError("Please enter a valid phone number.");
      return;
    }
    setError("");
    setIsSaving(true);
    try {
      await User.updateMyUserData({ phone_number: phoneNumber });
      onComplete();
    } catch (err) {
      console.error("Failed to save phone number:", err);
      setError("Failed to save. Please try again.");
    }
    setIsSaving(false);
  };

  return (
    <Dialog open={true}>
      <DialogContent className="sm:max-w-[425px]" hideCloseButton={true}>
        <DialogHeader>
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-100 to-blue-100 rounded-full flex items-center justify-center">
              <Smartphone className="w-8 h-8 text-purple-600" />
            </div>
          </div>
          <DialogTitle className="text-center text-2xl">Welcome!</DialogTitle>
          <DialogDescription className="text-center">
            To continue, please provide your phone number for notifications.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <Input
            id="phone"
            type="tel"
            placeholder="Enter your phone number"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            className="text-center"
          />
          {error && <p className="text-red-500 text-sm mt-2 text-center">{error}</p>}
        </div>
        <Button onClick={handleSubmit} disabled={isSaving} className="w-full">
          <Save className="w-4 h-4 mr-2" />
          {isSaving ? "Saving..." : "Save and Continue"}
        </Button>
      </DialogContent>
    </Dialog>
  );
}