import React, { useState, useRef } from "react";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  ExternalLink, 
  Bookmark,
  BookmarkCheck,
  Clock,
  TrendingUp,
  Zap,
  CheckCircle2,
  Youtube,
  ChevronRight,
  ChevronLeft
} from "lucide-react";
import { User } from "@/api/entities";

const categoryColors = {
  ai: "bg-purple-100 text-purple-800 border-purple-200",
  technology: "bg-blue-100 text-blue-800 border-blue-200", 
  startups: "bg-green-100 text-green-800 border-green-200",
  breaking: "bg-red-100 text-red-800 border-red-200"
};

const categoryIcons = {
  ai: "🤖",
  technology: "⚡",
  startups: "🚀", 
  breaking: "🚨"
};

export default function MobileNewsCard({ article, isBookmarked, onBookmarkToggle, onSwipe, currentIndex, totalCards }) {
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);
  const [swipeDirection, setSwipeDirection] = useState(null);
  const cardRef = useRef(null);
  const startXRef = useRef(0);
  const startYRef = useRef(0);

  // Touch/Swipe handlers
  const handleTouchStart = (e) => {
    const touch = e.touches[0];
    startXRef.current = touch.clientX;
    startYRef.current = touch.clientY;
    setSwipeDirection(null);
  };

  const handleTouchMove = (e) => {
    if (!startXRef.current || !startYRef.current) return;

    const touch = e.touches[0];
    const deltaX = touch.clientX - startXRef.current;
    const deltaY = touch.clientY - startYRef.current;

    // Only handle horizontal swipes (not vertical scrolling)
    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 30) {
      e.preventDefault();
      
      if (cardRef.current) {
        cardRef.current.style.transform = `translateX(${deltaX * 0.5}px)`;
        cardRef.current.style.transition = 'none';
        
        if (deltaX > 80) {
          setSwipeDirection('right');
        } else if (deltaX < -80) {
          setSwipeDirection('left');
        } else {
          setSwipeDirection(null);
        }
      }
    }
  };

  const handleTouchEnd = (e) => {
    if (!startXRef.current || !cardRef.current) return;

    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - startXRef.current;
    const deltaY = touch.clientY - startYRef.current;

    // Reset card position
    cardRef.current.style.transition = 'transform 0.3s ease';
    cardRef.current.style.transform = 'translateX(0)';

    // Handle swipe actions
    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 80) {
      if (deltaX > 80 && currentIndex > 0) {
        // Right swipe - Previous card
        onSwipe('prev');
      } else if (deltaX < -80 && currentIndex < totalCards - 1) {
        // Left swipe - Next card
        onSwipe('next');
      }
    }

    // Reset values
    startXRef.current = 0;
    startYRef.current = 0;
    setSwipeDirection(null);
  };

  const handleBookmark = async (e) => {
    e.stopPropagation();
    try {
      const user = await User.me();
      const bookmarks = user.bookmarked_articles || [];
      
      if (isBookmarked) {
        const newBookmarks = bookmarks.filter(id => id !== article.id);
        await User.updateMyUserData({ bookmarked_articles: newBookmarks });
      } else {
        await User.updateMyUserData({ 
          bookmarked_articles: [...bookmarks, article.id] 
        });
      }
      
      if (onBookmarkToggle) onBookmarkToggle(article.id, !isBookmarked);
    } catch (error) {
      console.error("Error updating bookmark:", error);
    }
  };

  const handleYoutubeSearch = (e) => {
    e.stopPropagation();
    const searchQuery = encodeURIComponent(article.title);
    window.open(`https://www.youtube.com/results?search_query=${searchQuery}`, '_blank', 'noopener,noreferrer');
  };

  const handleCardClick = (e) => {
    if (e.target.closest('button')) return;
    
    const searchQuery = encodeURIComponent(`${article.title} ${article.source}`);
    window.open(`https://www.google.com/search?q=${searchQuery}`, '_blank', 'noopener,noreferrer');
  };

  const handleImageLoad = () => setImageLoading(false);
  const handleImageError = () => {
    setImageError(true);
    setImageLoading(false);
  };

  return (
    <div className="relative">
      {/* Swipe Hints */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className={`absolute left-0 top-0 h-full w-16 bg-blue-500/20 flex items-center justify-center transition-opacity duration-200 ${swipeDirection === 'right' ? 'opacity-100' : 'opacity-0'}`}>
          <ChevronLeft className="w-8 h-8 text-blue-600" />
        </div>
        <div className={`absolute right-0 top-0 h-full w-16 bg-purple-500/20 flex items-center justify-center transition-opacity duration-200 ${swipeDirection === 'left' ? 'opacity-100' : 'opacity-0'}`}>
          <ChevronRight className="w-8 h-8 text-purple-600" />
        </div>
      </div>

      <Card 
        ref={cardRef}
        className="group cursor-pointer border shadow-lg bg-white relative z-10 max-w-md mx-auto"
        onClick={handleCardClick}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{ touchAction: 'pan-y' }}
      >
        {/* Swipe Instructions */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-20">
          <div className="bg-black/60 text-white text-xs px-3 py-1 rounded-full flex items-center gap-2">
            <span>👈 Next</span>
            <span>|</span>
            <span>Previous 👉</span>
          </div>
        </div>

        {article.image_url && !imageError ? (
          <div className="aspect-[16/9] overflow-hidden rounded-t-lg relative">
            {imageLoading && (
              <div className="absolute inset-0 bg-gray-100 flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
              </div>
            )}
            <img
              src={article.image_url}
              alt={article.title}
              className={`w-full h-full object-cover ${imageLoading ? 'opacity-0' : 'opacity-100'}`}
              onLoad={handleImageLoad}
              onError={handleImageError}
            />
          </div>
        ) : (
          <div className="aspect-[16/9] overflow-hidden rounded-t-lg bg-gray-100 flex items-center justify-center">
            <span className="text-6xl">{categoryIcons[article.category] || "📰"}</span>
          </div>
        )}
        
        <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
          {article.is_breaking && (
            <Badge className="bg-red-500 text-white border-0 shadow-lg animate-pulse">
              <Zap className="w-3 h-3 mr-1" />
              Breaking
            </Badge>
          )}
          {article.is_verified && (
            <Badge className="bg-green-500 text-white border-0 shadow-lg">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Verified
            </Badge>
          )}
        </div>

        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge className={`${categoryColors[article.category]} border font-medium`}>
                <span className="mr-1">{categoryIcons[article.category]}</span>
                {article.category.toUpperCase()}
              </Badge>
              {article.trending_score > 80 && (
                <Badge variant="outline" className="text-orange-600 border-orange-200">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  Trending
                </Badge>
              )}
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={handleBookmark}
              className="hover:bg-gray-100 p-2 z-10"
            >
              {isBookmarked ? (
                <BookmarkCheck className="w-4 h-4 text-purple-600" />
              ) : (
                <Bookmark className="w-4 h-4 text-gray-400 hover:text-purple-600" />
              )}
            </Button>
          </div>

          <h3 className="font-bold text-xl text-gray-900 mb-3 leading-tight">
            {article.title}
          </h3>

          <p className="text-gray-600 text-sm leading-relaxed mb-4">
            {article.summary}
          </p>

          <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
            <div className="flex items-center gap-4">
              <span className="font-medium">{article.source}</span>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {article.published_date && format(new Date(article.published_date), "MMM d, HH:mm")}
              </div>
            </div>
            
            <button
              onClick={handleYoutubeSearch}
              className="p-2 rounded-full hover:bg-red-100/50 transition-colors"
              title="Search on YouTube"
            >
              <Youtube className="w-5 h-5 text-red-500" />
            </button>
          </div>

          {article.tags && article.tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {article.tags.slice(0, 3).map((tag, index) => (
                <span
                  key={`${tag}-${index}`}
                  className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}