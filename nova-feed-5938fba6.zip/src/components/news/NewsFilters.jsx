
import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter, TrendingUp, Clock, Search } from "lucide-react";

const categories = [
  { value: "all", label: "All News", icon: "📰" },
  { value: "ai", label: "AI News", icon: "🤖" },
  { value: "technology", label: "Technology", icon: "⚡" }, 
  { value: "startups", label: "Startups", icon: "🚀" },
  { value: "breaking", label: "Breaking", icon: "🚨" },
  { value: "aitools", label: "AI Tools", icon: "🛠️" },
  { value: "seotools", label: "SEO Tools", icon: "📈" }
];

const sortOptions = [
  { value: "latest", label: "Latest First", icon: Clock },
  { value: "trending", label: "Trending", icon: TrendingUp }
];

export default function NewsFilters({ 
  activeCategory, 
  onCategoryChange, 
  sortBy, 
  onSortChange,
  breakingCount = 0,
  categoryCounts = { all: 0, ai: 0, technology: 0, startups: 0 },
  aiToolsCount = 0,
  seoToolsCount = 0
}) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 mb-6">
      <div className="flex flex-col gap-4">
        {/* Sort and Search */}
        <div className="flex items-center gap-4">
          <Select value={sortBy} onValueChange={onSortChange}>
            <SelectTrigger className="w-full md:w-40">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {sortOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  <div className="flex items-center gap-2">
                    <option.icon className="w-4 h-4" />
                    {option.label}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Category Buttons */}
        <div className="flex flex-wrap gap-2 items-center">
          {categories.slice(0, 4).map((category) => (
            <Button
              key={category.value}
              variant={activeCategory === category.value ? "default" : "outline"}
              onClick={() => onCategoryChange(category.value)}
              className={`transition-all duration-200 shrink-0 relative flex-grow md:flex-grow-0 ${
                activeCategory === category.value
                  ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-md"
                  : "hover:bg-gray-50 text-gray-700 border-gray-200"
              }`}
            >
              <span className="mr-2">{category.icon}</span>
              {category.label}
              {categoryCounts[category.value] > 0 && (
                <Badge
                  variant="secondary"
                  className={`ml-2 text-xs font-normal h-5 px-2 rounded-full transition-colors ${
                    activeCategory === category.value
                      ? 'bg-white/25 text-white'
                      : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {categoryCounts[category.value]}
                </Badge>
              )}
            </Button>
          ))}

          {/* Breaking News Button */}
          <Button
            variant={activeCategory === "breaking" ? "default" : "outline"}
            onClick={() => onCategoryChange("breaking")}
            className={`transition-all duration-200 shrink-0 relative flex-grow md:flex-grow-0 ${
              activeCategory === "breaking"
                ? "bg-gradient-to-r from-red-600 to-pink-600 text-white shadow-md"
                : "hover:bg-gray-50 text-gray-700 border-gray-200"
            }`}
          >
            <span className="mr-2">🚨</span>
            Breaking
            {breakingCount > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs animate-pulse">
                {breakingCount > 9 ? '9+' : breakingCount}
              </Badge>
            )}
          </Button>

          {/* AI Tools Button */}
          <Button
            variant={activeCategory === "aitools" ? "default" : "outline"}
            onClick={() => onCategoryChange("aitools")}
            className={`transition-all duration-200 shrink-0 relative flex-grow md:flex-grow-0 ${
              activeCategory === "aitools"
                ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md"
                : "hover:bg-gray-50 text-gray-700 border-gray-200"
            }`}
          >
            <span className="mr-2">🛠️</span>
            AI Tools
            {aiToolsCount > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 bg-purple-500 text-white text-xs">
                {aiToolsCount > 9 ? '9+' : aiToolsCount}
              </Badge>
            )}
          </Button>

          {/* SEO Tools Button */}
          <Button
            variant={activeCategory === "seotools" ? "default" : "outline"}
            onClick={() => onCategoryChange("seotools")}
            className={`transition-all duration-200 shrink-0 relative flex-grow md:flex-grow-0 ${
              activeCategory === "seotools"
                ? "bg-gradient-to-r from-teal-500 to-cyan-600 text-white shadow-md"
                : "hover:bg-gray-50 text-gray-700 border-gray-200"
            }`}
          >
            <Search className="w-4 h-4 mr-2" />
            SEO Tools
            {seoToolsCount > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 bg-teal-500 text-white text-xs">
                {seoToolsCount > 9 ? '9+' : seoToolsCount}
              </Badge>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
