
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { User } from "@/api/entities";
import { Bell, Save, CheckCircle, MessageCircle, Send } from "lucide-react";

const categories = [
  { value: "ai", label: "AI News", icon: "🧠" },
  { value: "technology", label: "Technology", icon: "⚡" }, 
  { value: "startups", label: "Startups", icon: "🚀" },
  { value: "breaking", label: "Breaking News", icon: "🚨" }
];

export default function NotificationSettings() {
  const [user, setUser] = useState(null);
  const [settings, setSettings] = useState({
    categories: ["ai", "technology", "startups", "breaking"],
    frequency: "hourly"
  });
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    loadUserSettings();
  }, []);

  const loadUserSettings = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData.notification_preferences) {
        setSettings({
          categories: userData.notification_preferences.categories || ["ai", "technology", "startups", "breaking"],
          frequency: userData.notification_preferences.frequency || "hourly"
        });
      }
    } catch (error) {
      console.error("Error loading user settings:", error);
    }
  };

  const handleSettingChange = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleCategoryToggle = (category) => {
    const newCategories = settings.categories.includes(category)
      ? settings.categories.filter(c => c !== category)
      : [...settings.categories, category];
    
    handleSettingChange("categories", newCategories);
  };

  const saveSettings = async () => {
    setIsSaving(true);
    try {
      await User.updateMyUserData({
        notification_preferences: settings
      });
      
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (error) {
      console.error("Error saving settings:", error);
    }
    setIsSaving(false);
  };

  return (
    <div className="space-y-6">
      {/* Telegram Bot */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-blue-500" />
            Join Our AI News Bot
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-xl p-6">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 text-center">
              🤖 All AI News Hub Bot
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6 text-center">
              Get instant AI, technology, and startup news updates directly via our Telegram bot
            </p>
            
            <div className="space-y-3 text-center">
              <p className="text-lg font-semibold text-purple-600 dark:text-purple-400 flex items-center justify-center gap-2">
                <Send className="w-5 h-5" />
                Start Chatting with Our Bot
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Bot Username: <span className="font-mono font-bold">@allainewshubbot</span>
              </p>
              
              <div className="flex justify-center">
                <Button 
                  onClick={() => window.open('https://t.me/allainewshubbot', '_blank')}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 text-lg"
                >
                  <Send className="w-5 h-5 mr-2" /> Start Bot
                </Button>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-center gap-2 text-gray-900 dark:text-gray-200">
              <Bell className="w-4 h-4" />
              <p className="text-sm font-medium">
                Start our bot to receive personalized AI news updates!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notification Frequency */}
      <Card>
        <CardHeader>
          <CardTitle>Notification Frequency</CardTitle>
        </CardHeader>
        <CardContent>
          <Select 
            value={settings.frequency} 
            onValueChange={(value) => handleSettingChange("frequency", value)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="immediate">Immediate (Breaking News)</SelectItem>
              <SelectItem value="hourly">Hourly Digest</SelectItem>
              <SelectItem value="daily">Daily Summary</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Categories */}
      <Card>
        <CardHeader>
          <CardTitle>News Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {categories.map((category) => (
              <div 
                key={category.value}
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="text-lg">{category.icon}</span>
                  <Label className="font-medium cursor-pointer">
                    {category.label}
                  </Label>
                </div>
                <Switch
                  checked={settings.categories.includes(category.value)}
                  onCheckedChange={() => handleCategoryToggle(category.value)}
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button 
          onClick={saveSettings}
          disabled={isSaving}
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
        >
          {saved ? (
            <>
              <CheckCircle className="w-4 h-4 mr-2" />
              Saved!
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              {isSaving ? "Saving..." : "Save Settings"}
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
