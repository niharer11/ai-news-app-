import React, { useEffect, useState } from "react";
import { RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function AutoRefresh() {
  const [nextRefreshTime, setNextRefreshTime] = useState(null);
  const [timeRemaining, setTimeRemaining] = useState(30 * 60); // 30 minutes in seconds

  useEffect(() => {
    // Set initial refresh time
    const now = new Date();
    const nextRefresh = new Date(now.getTime() + 30 * 60 * 1000); // 30 minutes from now
    setNextRefreshTime(nextRefresh);

    // Auto-refresh every 30 minutes
    const refreshInterval = setInterval(() => {
      console.log("🔄 Auto-refreshing website for latest data...");
      window.location.reload();
    }, 30 * 60 * 1000); // 30 minutes

    // Update countdown timer every second
    const countdownInterval = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          return 30 * 60; // Reset to 30 minutes
        }
        return prev - 1;
      });
    }, 1000);

    // Cleanup intervals
    return () => {
      clearInterval(refreshInterval);
      clearInterval(countdownInterval);
    };
  }, []);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Return null to hide the UI but keep the functionality
  return null;
}