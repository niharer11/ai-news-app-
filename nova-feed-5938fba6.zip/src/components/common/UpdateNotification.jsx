import React, { useState, useEffect } from "react";
import { Bell, X, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function UpdateNotification() {
  const [showNotification, setShowNotification] = useState(false);

  useEffect(() => {
    // Check if user should see update notification
    const lastUpdate = localStorage.getItem('last_app_update');
    const currentTime = Date.now();
    const oneDayAgo = currentTime - (24 * 60 * 60 * 1000);

    if (!lastUpdate || parseInt(lastUpdate) < oneDayAgo) {
      // Show update notification
      setTimeout(() => {
        setShowNotification(true);
      }, 2000); // Show after 2 seconds
    }
  }, []);

  const handleDismiss = () => {
    setShowNotification(false);
    localStorage.setItem('last_app_update', Date.now().toString());
  };

  const handleUpdate = () => {
    localStorage.setItem('last_app_update', Date.now().toString());
    window.location.reload();
  };

  if (!showNotification) return null;

  return (
    <div className="fixed top-4 right-4 z-50 max-w-sm">
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg shadow-lg p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-sm">App Updated!</h4>
              <p className="text-xs opacity-90 mt-1">
                New features and improvements available
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleDismiss}
            className="text-white hover:bg-white/20 h-6 w-6"
          >
            <X className="w-3 h-3" />
          </Button>
        </div>
        
        <div className="flex gap-2 mt-3">
          <Button
            size="sm"
            variant="ghost"
            onClick={handleDismiss}
            className="text-white hover:bg-white/20 text-xs"
          >
            Later
          </Button>
          <Button
            size="sm"
            onClick={handleUpdate}
            className="bg-white text-purple-600 hover:bg-gray-100 text-xs"
          >
            <Download className="w-3 h-3 mr-1" />
            Refresh
          </Button>
        </div>
      </div>
    </div>
  );
}