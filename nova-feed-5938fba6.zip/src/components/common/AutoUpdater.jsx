import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Download, Bell, X } from "lucide-react";

export default function AutoUpdater() {
  const [showUpdatePrompt, setShowUpdatePrompt] = useState(false);
  const [updateInfo, setUpdateInfo] = useState(null);

  useEffect(() => {
    // Check for updates every 30 minutes
    const checkInterval = setInterval(() => {
      checkForUpdates();
    }, 30 * 60 * 1000); // 30 minutes

    // Check immediately when component mounts
    checkForUpdates();

    return () => clearInterval(checkInterval);
  }, []);

  const checkForUpdates = () => {
    const currentVersion = localStorage.getItem('app_version') || '1.0.0';
    const latestVersion = '1.0.1'; // This will be dynamic in real implementation
    
    if (currentVersion !== latestVersion) {
      setUpdateInfo({
        currentVersion,
        latestVersion,
        features: [
          "🎯 Improved mobile responsiveness",
          "🚀 Faster news loading",
          "🔔 Better notification system", 
          "🎨 Enhanced UI/UX design",
          "🛡️ Security improvements"
        ]
      });
      setShowUpdatePrompt(true);
    }
  };

  const handleUpdate = () => {
    // Store new version
    localStorage.setItem('app_version', updateInfo.latestVersion);
    
    // Show success message
    alert('✅ Update completed! Refreshing page...');
    
    // Force refresh to get latest code
    window.location.reload();
  };

  const dismissUpdate = () => {
    setShowUpdatePrompt(false);
    // Set reminder for next check
    localStorage.setItem('update_dismissed', Date.now().toString());
  };

  if (!showUpdatePrompt) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center">
            <Download className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="flex items-center justify-between">
            <span>🎉 New Update Available!</span>
            <Button variant="ghost" size="icon" onClick={dismissUpdate}>
              <X className="w-4 h-4" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <Badge className="bg-green-100 text-green-800 mb-4">
              v{updateInfo?.currentVersion} → v{updateInfo?.latestVersion}
            </Badge>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-semibold text-gray-900">✨ What's New:</h4>
            <ul className="space-y-1 text-sm text-gray-600">
              {updateInfo?.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>

          <div className="flex gap-3 pt-4">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={dismissUpdate}
            >
              Later
            </Button>
            <Button 
              className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              onClick={handleUpdate}
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Update Now
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}