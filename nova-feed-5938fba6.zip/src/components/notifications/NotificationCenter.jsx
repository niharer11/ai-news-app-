import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
    Bell, 
    BellRing, 
    Check, 
    AlertTriangle, 
    Info, 
    CheckCircle,
    Zap,
    X
} from "lucide-react";
import { Notification } from "@/api/entities";
import { User } from "@/api/entities";
import { format } from "date-fns";

const notificationIcons = {
    info: Info,
    success: CheckCircle,
    warning: AlertTriangle,
    breaking: Zap
};

const notificationColors = {
    info: "text-blue-600 bg-blue-50",
    success: "text-green-600 bg-green-50", 
    warning: "text-yellow-600 bg-yellow-50",
    breaking: "text-red-600 bg-red-50"
};

export default function NotificationCenter() {
    const [notifications, setNotifications] = useState([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const [isOpen, setIsOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const intervalRef = useRef(null);

    useEffect(() => {
        loadNotifications();
        
        // Auto-refresh every 30 seconds with error handling
        if (!intervalRef.current) {
            intervalRef.current = setInterval(() => {
                loadNotifications(true); // Silent refresh
            }, 30000);
        }
        
        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
                intervalRef.current = null;
            }
        };
    }, []);

    const loadNotifications = async (silent = false) => {
        if (!silent) setLoading(true);
        setError(null);
        
        try {
            const user = await User.me();
            if (!user || !user.email) {
                if (intervalRef.current) {
                    clearInterval(intervalRef.current);
                    intervalRef.current = null;
                }
                setNotifications([]);
                setUnreadCount(0);
                return;
            }
            
            const userNotifications = await Notification.filter(
                { user_email: user.email },
                "-created_date",
                20
            );
            
            setNotifications(userNotifications || []);
            setUnreadCount((userNotifications || []).filter(n => !n.is_read).length);
        } catch (error) {
            console.warn("Notification loading error:", error.message);
            if (!silent) {
                setError("Failed to load notifications");
            }
            
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
                intervalRef.current = null;
            }
            setNotifications([]);
            setUnreadCount(0);
        } finally {
            if (!silent) setLoading(false);
        }
    };

    const markAsRead = async (notificationId) => {
        try {
            await Notification.update(notificationId, { is_read: true });
            await loadNotifications(true);
        } catch (error) {
            console.error("Error marking notification as read:", error);
            setError("Failed to mark as read");
        }
    };

    const markAllAsRead = async () => {
        setLoading(true);
        try {
            const unreadNotifications = notifications.filter(n => !n.is_read);
            for (const notification of unreadNotifications) {
                await Notification.update(notification.id, { is_read: true });
            }
            await loadNotifications(true);
        } catch (error) {
            console.error("Error marking all as read:", error);
            setError("Failed to mark all as read");
        }
        setLoading(false);
    };

    const handleNotificationClick = async (notification) => {
        try {
            if (!notification.is_read) {
                await markAsRead(notification.id);
            }
            
            if (notification.action_url) {
                window.open(notification.action_url, '_blank');
            }
        } catch (error) {
            console.error("Error handling notification click:", error);
        }
    };

    return (
        <div className="relative">
            <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(!isOpen)}
                className="relative hover:bg-gray-100 dark:hover:bg-gray-700"
            >
                {unreadCount > 0 ? (
                    <BellRing className="w-5 h-5 text-purple-600" />
                ) : (
                    <Bell className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                )}
                {unreadCount > 0 && (
                    <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs">
                        {unreadCount > 9 ? '9+' : unreadCount}
                    </Badge>
                )}
            </Button>

            {isOpen && (
                <div className="absolute right-0 top-full mt-2 w-96 z-50">
                    <Card className="shadow-xl border-0 dark:bg-gray-800 dark:border-gray-700">
                        <CardHeader className="flex flex-row items-center justify-between pb-3">
                            <CardTitle className="text-lg dark:text-white">Notifications</CardTitle>
                            <div className="flex items-center gap-2">
                                {unreadCount > 0 && (
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={markAllAsRead}
                                        disabled={loading}
                                        className="text-purple-600 hover:text-purple-700 hover:bg-purple-50 dark:text-purple-400 dark:hover:bg-purple-900/20"
                                    >
                                        <Check className="w-4 h-4 mr-1" />
                                        Mark all read
                                    </Button>
                                )}
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => setIsOpen(false)}
                                    className="h-8 w-8 dark:hover:bg-gray-700"
                                >
                                    <X className="w-4 h-4" />
                                </Button>
                            </div>
                        </CardHeader>
                        <CardContent className="p-0">
                            {error && (
                                <div className="p-4 text-center text-red-600 text-sm">
                                    {error}
                                    <Button 
                                        variant="ghost" 
                                        size="sm" 
                                        onClick={() => loadNotifications()}
                                        className="ml-2"
                                    >
                                        Retry
                                    </Button>
                                </div>
                            )}
                            
                            <ScrollArea className="h-96">
                                {notifications.length === 0 ? (
                                    <div className="flex flex-col items-center justify-center py-8 text-gray-500 dark:text-gray-400">
                                        <Bell className="w-12 h-12 mb-2 opacity-50" />
                                        <p className="text-sm">No notifications yet</p>
                                        <p className="text-xs">We'll notify you when there's news!</p>
                                    </div>
                                ) : (
                                    <div className="space-y-1">
                                        {notifications.map((notification) => {
                                            const IconComponent = notificationIcons[notification.type];
                                            return (
                                                <div
                                                    key={notification.id}
                                                    className={`p-4 border-b cursor-pointer transition-colors hover:bg-gray-50 dark:hover:bg-gray-700 dark:border-gray-600 ${
                                                        !notification.is_read ? 'bg-blue-50/50 dark:bg-blue-900/10' : ''
                                                    }`}
                                                    onClick={() => handleNotificationClick(notification)}
                                                >
                                                    <div className="flex gap-3">
                                                        <div className={`rounded-full p-2 ${notificationColors[notification.type]} dark:bg-opacity-20`}>
                                                            <IconComponent className="w-4 h-4" />
                                                        </div>
                                                        <div className="flex-1 min-w-0">
                                                            <div className="flex items-start justify-between">
                                                                <h4 className={`text-sm font-medium ${
                                                                    !notification.is_read ? 'text-gray-900 dark:text-white' : 'text-gray-600 dark:text-gray-300'
                                                                }`}>
                                                                    {notification.title}
                                                                </h4>
                                                                {!notification.is_read && (
                                                                    <div className="w-2 h-2 bg-purple-600 rounded-full mt-1 ml-2 flex-shrink-0"></div>
                                                                )}
                                                            </div>
                                                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
                                                                {notification.message}
                                                            </p>
                                                            <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">
                                                                {format(new Date(notification.created_date), 'MMM d, HH:mm')}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </ScrollArea>
                        </CardContent>
                    </Card>
                </div>
            )}
        </div>
    );
}