
import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter, TrendingUp, Clock, Sparkles, Crown } from "lucide-react";

const categories = [
  { value: "all", label: "All Tools", icon: "🛠️" },
  { value: "text-generation", label: "Text AI", icon: "✏️" },
  { value: "image-generation", label: "Image AI", icon: "🎨" },
  { value: "code-generation", label: "Code AI", icon: "💻" },
  { value: "chatbot", label: "Chatbots", icon: "🤖" },
  { value: "productivity", label: "Productivity", icon: "⚡" },
  { value: "design", label: "Design", icon: "🎯" },
  { value: "seo", label: "SEO", icon: "📈" }
];

const sortOptions = [
  { value: "latest", label: "Latest First", icon: Clock },
  { value: "popular", label: "Most Popular", icon: TrendingUp }
];

export default function AIToolFilters({ 
  activeCategory, 
  onCategoryChange, 
  sortBy, 
  onSortChange,
  categoryCounts = { all: 0, trending: 0, new: 0, free: 0 },
  tools = [] // Add tools prop to calculate real-time counts
}) {
  // Calculate real-time counts from tools data
  const realTimeCounts = {
    all: tools.length,
    "text-generation": tools.filter(t => t.category === "text-generation").length,
    "image-generation": tools.filter(t => t.category === "image-generation").length,
    "code-generation": tools.filter(t => t.category === "code-generation").length,
    "chatbot": tools.filter(t => t.category === "chatbot").length,
    "productivity": tools.filter(t => t.category === "productivity").length,
    "design": tools.filter(t => t.category === "design").length,
    "seo": tools.filter(t => t.category === "seo").length,
    trending: tools.filter(t => t.is_trending).length,
    new: tools.filter(t => t.is_new).length,
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 mb-6">
      <div className="flex flex-col gap-4">
        {/* Sort and Search */}
        <div className="flex items-center gap-4">
          <Select value={sortBy} onValueChange={onSortChange}>
            <SelectTrigger className="w-full md:w-40">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {sortOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  <div className="flex items-center gap-2">
                    <option.icon className="w-4 h-4" />
                    {option.label}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Category Buttons */}
        <div className="flex flex-wrap gap-2 items-center">
          {categories.map((category) => (
            <Button
              key={category.value}
              variant={activeCategory === category.value ? "default" : "outline"}
              onClick={() => onCategoryChange(category.value)}
              className={`transition-all duration-200 shrink-0 flex-grow md:flex-grow-0 ${
                activeCategory === category.value
                  ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md"
                  : "hover:bg-gray-50 text-gray-700 border-gray-200"
              }`}
            >
              <span className="mr-2">{category.icon}</span>
              {category.label}
              {realTimeCounts[category.value] > 0 && (
                <Badge
                  variant="secondary"
                  className={`ml-2 text-xs font-normal h-5 px-2 rounded-full ${
                    activeCategory === category.value
                      ? 'bg-white/25 text-white'
                      : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {realTimeCounts[category.value]}
                </Badge>
              )}
            </Button>
          ))}

          {/* Trending Button */}
          <Button
            variant={activeCategory === "trending" ? "default" : "outline"}
            onClick={() => onCategoryChange("trending")}
            className={`transition-all duration-200 shrink-0 relative flex-grow md:flex-grow-0 ${
              activeCategory === "trending"
                ? "bg-gradient-to-r from-orange-600 to-red-600 text-white shadow-md"
                : "hover:bg-gray-50 text-gray-700 border-gray-200"
            }`}
          >
            <TrendingUp className="w-4 h-4 mr-2" />
            Trending
            {realTimeCounts.trending > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs">
                {realTimeCounts.trending}
              </Badge>
            )}
          </Button>

          {/* New Button */}
          <Button
            variant={activeCategory === "new" ? "default" : "outline"}
            onClick={() => onCategoryChange("new")}
            className={`transition-all duration-200 shrink-0 relative flex-grow md:flex-grow-0 ${
              activeCategory === "new"
                ? "bg-gradient-to-r from-green-600 to-emerald-600 text-white shadow-md"
                : "hover:bg-gray-50 text-gray-700 border-gray-200"
            }`}
          >
            <Sparkles className="w-4 h-4 mr-2" />
            New
            {realTimeCounts.new > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 bg-green-500 text-white text-xs">
                {realTimeCounts.new}
              </Badge>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
