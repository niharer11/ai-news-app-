import React, { useState } from "react";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  ExternalLink, 
  Bookmark,
  BookmarkCheck,
  Clock,
  TrendingUp,
  Sparkles,
  Zap,
  Crown,
  Youtube
} from "lucide-react";
import { User } from "@/api/entities";

const categoryColors = {
  "text-generation": "bg-blue-100 text-blue-800 border-blue-200",
  "image-generation": "bg-purple-100 text-purple-800 border-purple-200",
  "code-generation": "bg-green-100 text-green-800 border-green-200",
  "video-generation": "bg-red-100 text-red-800 border-red-200",
  "audio-generation": "bg-yellow-100 text-yellow-800 border-yellow-200",
  "productivity": "bg-indigo-100 text-indigo-800 border-indigo-200",
  "analytics": "bg-cyan-100 text-cyan-800 border-cyan-200",
  "chatbot": "bg-pink-100 text-pink-800 border-pink-200",
  "automation": "bg-orange-100 text-orange-800 border-orange-200",
  "design": "bg-teal-100 text-teal-800 border-teal-200",
  "seo": "bg-emerald-100 text-emerald-800 border-emerald-200"
};

const categoryIcons = {
  "text-generation": "✏️",
  "image-generation": "🎨",
  "code-generation": "💻",
  "video-generation": "🎬",
  "audio-generation": "🎵",
  "productivity": "⚡",
  "analytics": "📊",
  "chatbot": "🤖",
  "automation": "🔄",
  "design": "🎯",
  "seo": "📈"
};

const pricingColors = {
  free: "bg-green-100 text-green-800",
  freemium: "bg-blue-100 text-blue-800",
  paid: "bg-orange-100 text-orange-800",
  subscription: "bg-purple-100 text-purple-800"
};

export default function AIToolCard({ tool, isBookmarked, onBookmarkToggle }) {
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);

  const handleBookmark = async (e) => {
    e.stopPropagation();
    try {
      const user = await User.me();
      const bookmarks = user.bookmarked_tools || [];
      
      if (isBookmarked) {
        const newBookmarks = bookmarks.filter(id => id !== tool.id);
        await User.updateMyUserData({ bookmarked_tools: newBookmarks });
      } else {
        await User.updateMyUserData({ 
          bookmarked_tools: [...bookmarks, tool.id] 
        });
      }
      
      if (onBookmarkToggle) onBookmarkToggle(tool.id, !isBookmarked);
    } catch (error) {
      console.error("Error updating bookmark:", error);
    }
  };

  const handleYoutubeSearch = (e) => {
    e.stopPropagation();
    const searchQuery = encodeURIComponent(`${tool.name} AI tool tutorial review`);
    window.open(`https://www.youtube.com/results?search_query=${searchQuery}`, '_blank', 'noopener,noreferrer');
  };

  const handleCardClick = (e) => {
    if (e.target.closest('button')) {
      return;
    }
    
    if (tool.website_url) {
      window.open(tool.website_url, '_blank', 'noopener,noreferrer');
    }
  };

  const handleImageLoad = () => {
    setImageLoading(false);
  };

  const handleImageError = () => {
    setImageError(true);
    setImageLoading(false);
  };

  return (
    <Card 
      className="group hover:shadow-lg transition-all duration-300 cursor-pointer border shadow-sm hover:shadow-xl hover:-translate-y-1 bg-white relative"
      onClick={handleCardClick}
    >
      {tool.logo_url && !imageError ? (
        <div className="aspect-[16/9] overflow-hidden rounded-t-lg relative">
          {imageLoading && (
            <div className="absolute inset-0 bg-gray-100 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
            </div>
          )}
          <img
            src={tool.logo_url}
            alt={tool.name}
            className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ${imageLoading ? 'opacity-0' : 'opacity-100'}`}
            onLoad={handleImageLoad}
            onError={handleImageError}
          />
        </div>
      ) : (
        <div className="aspect-[16/9] overflow-hidden rounded-t-lg bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center">
          <span className="text-4xl">{categoryIcons[tool.category] || "🛠️"}</span>
        </div>
      )}
      
      <div className="absolute top-4 left-4 z-10 flex gap-2">
        {tool.is_new && (
          <Badge className="bg-green-500 text-white border-0 shadow-lg">
            <Sparkles className="w-3 h-3 mr-1" />
            New
          </Badge>
        )}
        {tool.is_trending && (
          <Badge className="bg-orange-500 text-white border-0 shadow-lg">
            <TrendingUp className="w-3 h-3 mr-1" />
            Trending
          </Badge>
        )}
      </div>

      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge className={`${categoryColors[tool.category]} border font-medium`}>
              <span className="mr-1">{categoryIcons[tool.category]}</span>
              {tool.category.replace('-', ' ')}
            </Badge>
            <Badge className={`${pricingColors[tool.pricing]} border font-medium`}>
              {tool.pricing === 'free' && <span className="mr-1">🆓</span>}
              {tool.pricing === 'subscription' && <span className="mr-1">💎</span>}
              {tool.pricing.toUpperCase()}
            </Badge>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={handleBookmark}
            className="hover:bg-gray-100 p-2 z-10"
          >
            {isBookmarked ? (
              <BookmarkCheck className="w-4 h-4 text-purple-600" />
            ) : (
              <Bookmark className="w-4 h-4 text-gray-400 hover:text-purple-600" />
            )}
          </Button>
        </div>

        <h3 className="font-bold text-xl text-gray-900 mb-2 group-hover:text-purple-600 transition-colors duration-200">
          {tool.name}
        </h3>

        <p className="text-sm text-purple-600 font-medium mb-3">
          by {tool.company}
        </p>

        <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-2">
          {tool.description}
        </p>

        {tool.features && tool.features.length > 0 && (
          <div className="mb-4">
            <div className="flex flex-wrap gap-1">
              {tool.features.slice(0, 2).map((feature, index) => (
                <span
                  key={`${feature}-${index}`}
                  className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
                >
                  {feature}
                </span>
              ))}
              {tool.features.length > 2 && (
                <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                  +{tool.features.length - 2} more
                </span>
              )}
            </div>
          </div>
        )}

        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {tool.launch_date && format(new Date(tool.launch_date), "MMM d, yyyy")}
            </div>
            {tool.popularity_score > 80 && (
              <div className="flex items-center gap-1 text-orange-600">
                <Crown className="w-3 h-3" />
                Popular
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={handleYoutubeSearch}
              className="p-1 rounded-full hover:bg-red-100/50 transition-colors"
              title="Search AI Tool on YouTube"
            >
              <Youtube className="w-4 h-4 text-red-500" />
            </button>
            <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              <ExternalLink className="w-4 h-4" />
            </div>
          </div>
        </div>

        {tool.tags && tool.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-4">
            {tool.tags.slice(0, 3).map((tag, index) => (
              <span
                key={`${tag}-${index}`}
                className="text-xs text-purple-600 bg-purple-50 px-2 py-1 rounded-full"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}