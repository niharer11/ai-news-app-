
import React, { useState, useEffect } from "react";
import { AITool } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM, GenerateImage } from "@/api/integrations";
import AIToolCard from "../components/aitools/AIToolCard";
import AIToolFilters from "../components/aitools/AIToolFilters";
import LoadingState from "../components/news/LoadingState";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Wrench, Sparkles } from "lucide-react";

export default function AITools() {
  const [tools, setTools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeCategory, setActiveCategory] = useState("all");
  const [sortBy, setSortBy] = useState("latest");
  const [bookmarkedTools, setBookmarkedTools] = useState([]);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const category = urlParams.get('category');
    if (category) {
        setActiveCategory(category);
    }
    
    loadInitialData();
    
    // Auto-refresh AI tools every 2 hours
    const toolsInterval = setInterval(() => {
      console.log("🔄 Auto-updating AI tools...");
      loadTools();
    }, 2 * 60 * 60 * 1000); // 2 hours
    
    return () => clearInterval(toolsInterval);
  }, []);

  useEffect(() => {
    if (!loading) {
      loadTools();
    }
  }, [sortBy]);

  const loadInitialData = async () => {
    try {
      const userData = await User.me();
      setBookmarkedTools(userData.bookmarked_tools || []);
      
      await loadTools();
    } catch (error) {
      console.error("Error loading initial data:", error);
    }
    setLoading(false);
  };

  const loadTools = async () => {
    try {
      const sortField = sortBy === "latest" ? "-launch_date" : "-popularity_score";
      const fetchedTools = await AITool.list(sortField, 100);
      setTools(fetchedTools);
    } catch (error) {
      console.error("Error loading AI tools:", error);
    }
  };

  const fetchLatestAITools = async () => {
    setRefreshing(true);
    try {
      const response = await InvokeLLM({
        prompt: `Generate 10 latest AI tools launched or updated in the past week. **It is critical to include recently launched or updated AI-powered SEO tools.** Search specifically for new tools related to AI keyword research, AI content optimization, AI-driven technical SEO analysis, and AI link building assistants. 
        
Also find tools in other categories like:
- New AI tools for text generation, image generation, code generation
- Productivity AI tools and automation tools
- New AI chatbots and voice assistants
- Analytics and data AI tools
        
For each tool, provide:
- name: Exact tool name
- description: Brief 1-line description
- detailed_description: 2-3 sentences with key features
- category: Choose from: "text-generation", "image-generation", "code-generation", "video-generation", "audio-generation", "productivity", "analytics", "chatbot", "automation", "design", "seo"
- website_url: Realistic website URL (use real domains when possible)
- pricing: Choose from: "free", "freemium", "paid", "subscription"
- launch_date: Recent date in ISO format
- company: Company or creator name
- features: Array of 3-4 key features
- tags: Array of 2-3 relevant tags
- popularity_score: Score from 1-100
- is_trending: Boolean for popular tools
- is_new: Boolean (true for recently launched)

Make tools diverse across categories and realistic.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            tools: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  description: { type: "string" },
                  detailed_description: { type: "string" },
                  category: { 
                    type: "string", 
                    enum: ["text-generation", "image-generation", "code-generation", "video-generation", "audio-generation", "productivity", "analytics", "chatbot", "automation", "design", "seo"] 
                  },
                  website_url: { type: "string" },
                  pricing: { type: "string", enum: ["free", "freemium", "paid", "subscription"] },
                  launch_date: { type: "string" },
                  company: { type: "string" },
                  features: { type: "array", items: { type: "string" } },
                  tags: { type: "array", items: { type: "string" } },
                  popularity_score: { type: "number" },
                  is_trending: { type: "boolean" },
                  is_new: { type: "boolean" }
                }
              }
            }
          }
        }
      });

      if (response?.tools?.length > 0) {
        let newToolsCount = 0;

        for (const tool of response.tools) {
          try {
            // Generate logo image for each tool
            let logoUrl = null;
            try {
              const logoResponse = await GenerateImage({
                prompt: `Create a professional, minimalist logo for AI tool "${tool.name}". 
                Requirements:
                - Clean, modern design with tech aesthetic
                - ${tool.category.includes('image') ? 'Image/visual elements with camera or picture icons' :
                  tool.category.includes('text') ? 'Text/writing elements with document or pen icons' :
                  tool.category.includes('code') ? 'Code/programming elements with brackets or terminal icons' :
                  tool.category.includes('chat') ? 'Chat/communication elements with speech bubbles' :
                  tool.category.includes('seo') ? 'SEO/marketing elements with a magnifying glass or graph icons' :
                  'AI/tech elements with brain or circuit patterns'}
                - Professional gradient background (blue to purple)
                - Tool name "${tool.name}" prominently displayed
                - Square format, high resolution
                - Corporate logo style, not cartoon`
              });
              
              if (logoResponse?.url) {
                logoUrl = logoResponse.url;
              }
            } catch (imageError) {
              console.log("Failed to generate logo:", imageError);
            }

            const createdTool = await AITool.create({
              ...tool,
              logo_url: logoUrl,
              launch_date: tool.launch_date || new Date().toISOString()
            });

            newToolsCount++;

          } catch (error) {
            console.log("Tool might already exist or creation error:", error);
          }
        }

        console.log(`📊 AI Tools Update: ${newToolsCount} new tools added`);
        await loadTools();
      }

    } catch (error) {
      console.error("Error fetching AI tools:", error);
    }
    setRefreshing(false);
  };

  const handleBookmarkToggle = (toolId, isBookmarked) => {
    if (isBookmarked) {
      setBookmarkedTools(prev => [...prev, toolId]);
    } else {
      setBookmarkedTools(prev => prev.filter(id => id !== toolId));
    }
  };

  const filteredTools = tools.filter(tool => {
    if (activeCategory === "all") return true;
    if (activeCategory === "trending") return tool.is_trending;
    if (activeCategory === "new") return tool.is_new;
    return tool.category === activeCategory;
  });

  // Get counts for categories
  const categoryCounts = {
    all: tools.length,
    trending: tools.filter(t => t.is_trending).length,
    new: tools.filter(t => t.is_new).length,
    free: tools.filter(t => t.pricing === 'free').length,
  };

  if (loading) return <LoadingState />;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
              <Wrench className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">AI Tools</h1>
              <p className="text-gray-600">Discover the latest AI tools and applications</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-purple-600 border-purple-200">
                🛠️ {tools.length} Tools Available
              </Badge>
              <Badge variant="outline" className="text-pink-600 border-pink-200">
                <Sparkles className="w-3 h-3 mr-1" />
                Updated Hourly
              </Badge>
            </div>
            
            <Button 
              onClick={fetchLatestAITools}
              disabled={refreshing}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              {refreshing ? "Updating Tools..." : "Update Tools"}
            </Button>
          </div>
        </div>

        {/* Filters */}
        <AIToolFilters 
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
          sortBy={sortBy}
          onSortChange={setSortBy}
          categoryCounts={categoryCounts}
          tools={tools}
        />

        {/* Tools Grid */}
        {filteredTools.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Wrench className="w-12 h-12 text-purple-600" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">No AI tools found</h3>
            <p className="text-gray-500">Check back soon for the latest AI tools</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTools.map((tool) => (
              <AIToolCard
                key={tool.id}
                tool={tool}
                isBookmarked={bookmarkedTools.includes(tool.id)}
                onBookmarkToggle={handleBookmarkToggle}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
