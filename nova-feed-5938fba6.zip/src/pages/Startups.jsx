import React, { useState, useEffect } from "react";
import { NewsArticle } from "@/api/entities";
import { User } from "@/api/entities";
import NewsCard from "../components/news/NewsCard";
import LoadingState from "../components/news/LoadingState";
import { Badge } from "@/components/ui/badge";
import { Rocket } from "lucide-react";

export default function Startups() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [bookmarkedArticles, setBookmarkedArticles] = useState([]);

  useEffect(() => {
    loadStartupNews();
  }, []);

  const loadStartupNews = async () => {
    try {
      const userData = await User.me();
      setBookmarkedArticles(userData.bookmarked_articles || []);
      
      const startupArticles = await NewsArticle.filter(
        { category: "startups" }, 
        "-published_date", 
        30
      );
      setArticles(startupArticles);
    } catch (error) {
      console.error("Error loading startup news:", error);
    }
    setLoading(false);
  };

  const handleBookmarkToggle = (articleId, isBookmarked) => {
    if (isBookmarked) {
      setBookmarkedArticles(prev => [...prev, articleId]);
    } else {
      setBookmarkedArticles(prev => prev.filter(id => id !== articleId));
    }
  };

  if (loading) return <LoadingState />;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
              <Rocket className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">Startup News</h1>
              <p className="text-gray-600">Funding rounds, launches, and startup stories</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-green-600 border-green-200">
              🚀 {articles.length} Startup Stories
            </Badge>
            <Badge variant="outline" className="text-gray-600">
              Fresh updates
            </Badge>
          </div>
        </div>

        {/* News Grid */}
        {articles.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Rocket className="w-12 h-12 text-green-600" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">No startup news yet</h3>
            <p className="text-gray-500">Check back soon for the latest startup updates</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article) => (
              <NewsCard
                key={article.id}
                article={article}
                isBookmarked={bookmarkedArticles.includes(article.id)}
                onBookmarkToggle={handleBookmarkToggle}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}