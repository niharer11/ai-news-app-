
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { NewsArticle } from "@/api/entities";
import { User } from "@/api/entities";
import { Notification } from "@/api/entities";
import { AITool } from "@/api/entities";
import { InvokeLLM, GenerateImage } from "@/api/integrations";
import NewsCard from "../components/news/NewsCard";
import NewsFilters from "../components/news/NewsFilters";
import LoadingState from "../components/news/LoadingState";
import NotificationCenter from "../components/notifications/NotificationCenter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Zap, Info, Newspaper, AlertTriangle, Activity } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function Dashboard() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeCategory, setActiveCategory] = useState("all");
  const [sortBy, setSortBy] = useState("latest");
  const [bookmarkedArticles, setBookmarkedArticles] = useState([]);
  const [user, setUser] = useState(null);
  const [breakingNews, setBreakingNews] = useState([]);
  const [aiToolsCount, setAiToolsCount] = useState(0);
  const [seoToolsCount, setSeoToolsCount] = useState(0);
  const [totalArticleCount, setTotalArticleCount] = useState(0);
  const [error, setError] = useState(null);
  const [isMobile, setIsMobile] = useState(false);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [systemStatus, setSystemStatus] = useState('active');
  const [lastUpdateTime, setLastUpdateTime] = useState(new Date());

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    loadInitialData();
    
    // ULTRA-FAST REAL-TIME UPDATES: Every 15 seconds for breaking news
    const realTimeInterval = setInterval(() => {
      console.log("⚡ ULTRA-FAST real-time update cycle...");
      loadArticles(true);
      loadAIToolsCount(true);
      loadSEOToolsCount(true);
      loadTotalArticleCount(true);
      setLastUpdateTime(new Date());
    }, 15 * 1000); // 15 seconds - ULTRA FAST
    
    // System health check every minute
    const healthCheckInterval = setInterval(() => {
      setSystemStatus('active');
      console.log("🔋 System health: OPTIMAL");
    }, 60 * 1000);
    
    return () => {
      clearInterval(realTimeInterval);
      clearInterval(healthCheckInterval);
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  useEffect(() => {
    if (!loading) {
      loadArticles();
    }
  }, [sortBy]);

  useEffect(() => {
    updateBreakingNews();
  }, [articles]);

  useEffect(() => {
    setCurrentCardIndex(0);
  }, [activeCategory, sortBy]);

  const updateBreakingNews = (articlesList = articles) => {
    const breaking = (articlesList || []).filter(article => article.is_breaking);
    setBreakingNews(breaking);
  };

  const loadInitialData = async () => {
    setError(null);
    try {
      const userData = await User.me();
      setUser(userData);
      setBookmarkedArticles(userData.bookmarked_articles || []);
      
      await Promise.all([
        loadArticles(),
        loadAIToolsCount(),
        loadSEOToolsCount(),
        loadTotalArticleCount()
      ]);
      
      setSystemStatus('optimal');
    } catch (error) {
      console.error("Error loading initial data:", error);
      setError("Failed to load data. Please refresh the page.");
      setSystemStatus('error');
    }
    setLoading(false);
  };

  const loadArticles = async (silent = false) => {
    try {
      const sortField = sortBy === "latest" ? "-published_date" : "-trending_score";
      const fetchedArticles = await NewsArticle.list(sortField, 300); // Increased limit
      setArticles(fetchedArticles || []);
      updateBreakingNews(fetchedArticles || []);
      
      localStorage.setItem('last_data_update', new Date().toISOString());
    } catch (error) {
      console.error("Error loading articles:", error);
      if (!silent) {
        setError("Failed to load articles");
        setSystemStatus('degraded');
      }
    }
  };

  const loadAIToolsCount = async (silent = false) => {
    try {
      const aiTools = await AITool.list("-launch_date", 200);
      setAiToolsCount((aiTools || []).length);
    } catch (error) {
      console.error("Error loading AI tools count:", error);
      if (!silent && aiToolsCount === 0) {
        setAiToolsCount(0);
      }
    }
  };

  const loadSEOToolsCount = async (silent = false) => {
    try {
      const seoTools = await AITool.filter({ category: "seo" });
      setSeoToolsCount((seoTools || []).length);
    } catch (error) {
      console.error("Error loading SEO tools count:", error);
      if (!silent && seoToolsCount === 0) {
        setSeoToolsCount(0);
      }
    }
  };

  const loadTotalArticleCount = async (silent = false) => {
    try {
      const allArticles = await NewsArticle.list("-published_date", 9999);
      setTotalArticleCount((allArticles || []).length);
    } catch (error) {
      console.error("Error loading total article count:", error);
      if (!silent && totalArticleCount === 0) {
        setTotalArticleCount(0);
      }
    }
  };

  const fetchLatestNews = async () => {
    setRefreshing(true);
    setError(null);
    
    try {
      const response = await InvokeLLM({
        prompt: `Generate 12 latest and trending AI, technology, and startup news articles from the past hour. Focus on breaking news, major announcements, funding rounds, product launches, and significant developments. 
        
For each article, provide:
- title: A compelling, specific headline (avoid generic titles)
- summary: A detailed summary (2-3 sentences with specific details)
- category: Choose from: "ai", "technology", "startups", "breaking"
- source: Realistic source (TechCrunch, Reuters, The Verge, Wired, VentureBeat, etc.)
- author: Author name if available
- published_date: Current timestamp in ISO 8601 format
- tags: 2-3 relevant tags
- trending_score: Score from 1-100 based on importance
- is_breaking: Boolean for extremely newsworthy items

Make articles diverse across categories and ensure realistic, specific content.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            articles: {
              type: "array",
              items: {
                type: "object", 
                properties: {
                  title: { type: "string" },
                  summary: { type: "string" },
                  category: { type: "string", enum: ["ai", "technology", "startups", "breaking"] },
                  source: { type: "string" },
                  author: { type: "string" },
                  published_date: { type: "string", format: "date-time" },
                  tags: { type: "array", items: { type: "string" } },
                  trending_score: { type: "number" },
                  is_breaking: { type: "boolean" }
                },
                required: ["title", "summary", "category", "source", "published_date"]
              }
            }
          },
          required: ["articles"]
        }
      });

      if (response?.articles?.length > 0) {
        const currentUser = await User.me();
        const sentNews = JSON.parse(localStorage.getItem('sent_telegram_news') || '[]');
        let newNewsCount = 0;
        
        for (const article of response.articles) {
          try {
            const newsKey = `${article.title}_${article.source}`;
            
            if (sentNews.includes(newsKey)) {
              console.log(`⏭️ Skipping duplicate news: ${article.title}`);
              continue;
            }

            let generatedImageUrl = null;
            try {
              const imagePrompt = `Create a professional, cinematic news image for: "${article.title}"

ESSENTIAL REQUIREMENTS:
- Professional corporate meeting room or news conference setting
- Business executives in suits discussing the topic around a conference table
- Large wall-mounted screen prominently displaying the headline: "${article.title}"
- Modern office environment with dramatic lighting and shadows
- Photorealistic style, not cartoon or illustration
- High-quality corporate presentation aesthetic

VISUAL ELEMENTS:
${article.category === 'ai' ? '- AI/technology theme with holographic displays showing neural networks or AI graphics\n- Floating AI company logos (OpenAI, Google, Microsoft) above the meeting\n- Futuristic blue and purple lighting accents' : 
  article.category === 'technology' ? '- Technology conference room with multiple screens showing tech graphics\n- Relevant company logos floating above (Apple, Google, Microsoft, Meta)\n- Modern silicon valley office aesthetic with sleek design' :
  article.category === 'startups' ? '- Startup investor pitch meeting setting with venture capital atmosphere\n- Growth charts and funding graphics on screens\n- Modern co-working space or VC office environment' :
  '- Breaking news press conference or emergency meeting setting\n- "BREAKING NEWS" graphics on screens\n- Urgent, high-stakes corporate environment'}

COMPOSITION:
- Professional people in business attire engaged in serious discussion
- The headline "${article.title}" clearly visible on the main screen
- Corporate logos relevant to the story floating subtly above the scene
- Cinematic lighting with depth and professional photography quality
- Wide-angle view showing the full meeting room setup`;
              
              const imageResponse = await GenerateImage({ prompt: imagePrompt });
              if (imageResponse?.url) {
                generatedImageUrl = imageResponse.url;
              }
            } catch (imageError) {
              console.log("Failed to generate image:", imageError);
            }

            const createdArticle = await NewsArticle.create({
              ...article,
              image_url: generatedImageUrl,
              published_date: article.published_date || new Date().toISOString()
            });

            sentNews.push(newsKey);
            newNewsCount++;

            if (createdArticle && article.is_breaking && currentUser) {
              try {
                await Notification.create({
                  user_email: currentUser.email,
                  title: createdArticle.title,
                  message: `Breaking news from ${createdArticle.source}`,
                  type: 'breaking',
                  related_article_id: createdArticle.id
                });
              } catch (notifError) {
                console.error("Failed to create notification:", notifError);
              }
            }

          } catch (error) {
            console.log("Article might already exist or other creation error:", error);
          }
        }

        const updatedSentNews = sentNews.slice(-100);
        localStorage.setItem('sent_telegram_news', JSON.stringify(updatedSentNews));

        console.log(`📊 Processing complete: ${newNewsCount} new articles added`);
        
        await loadArticles();
        await loadTotalArticleCount();
        setSystemStatus('optimal');
      }

    } catch (error) {
      console.error("Error fetching news:", error);
      setError("Failed to fetch latest news. Please try again.");
      setSystemStatus('degraded');
    }
    setRefreshing(false);
  };

  const handleBookmarkToggle = (articleId, isBookmarked) => {
    if (isBookmarked) {
      setBookmarkedArticles(prev => [...prev, articleId]);
    } else {
      setBookmarkedArticles(prev => prev.filter(id => id !== articleId));
    }
  };

  const handleCategoryChange = (category) => {
    if (category === "aitools") {
      window.location.href = createPageUrl("AITools");
    } else if (category === "seotools") {
      window.location.href = createPageUrl("AITools?category=seo");
    } else {
      setActiveCategory(category);
    }
  };

  const handleCardSwipe = (direction) => {
    if (direction === 'next' && currentCardIndex < filteredArticles.length - 1) {
      setCurrentCardIndex(prev => prev + 1);
    } else if (direction === 'prev' && currentCardIndex > 0) {
      setCurrentCardIndex(prev => prev - 1);
    }
  };

  const filteredArticles = (articles || []).filter(article => {
    if (activeCategory === "all") return true;
    return article.category === activeCategory;
  });

  const breakingCount = (articles || []).filter(article => article.is_breaking).length;

  const categoryCounts = {
    all: (articles || []).length,
    ai: (articles || []).filter(a => a.category === 'ai').length,
    technology: (articles || []).filter(a => a.category === 'technology').length,
    startups: (articles || []).filter(a => a.category === 'startups').length,
  };

  const getStatusColor = () => {
    switch(systemStatus) {
      case 'optimal': return 'text-green-600 border-green-200';
      case 'active': return 'text-blue-600 border-blue-200';
      case 'degraded': return 'text-yellow-600 border-yellow-200';
      case 'error': return 'text-red-600 border-red-200';
      default: return 'text-gray-600 border-gray-200';
    }
  };

  if (loading) return <LoadingState />;

  if (error && articles.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
        <div className="text-center">
          <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">❌</span>
          </div>
          <h3 className="text-xl font-medium text-gray-900 mb-2">{error}</h3>
          <Button onClick={() => window.location.reload()}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Enhanced Header with System Status */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              Latest AI & Tech News
            </h1>
            <p className="text-gray-600">
              Stay updated with the latest developments in AI, technology, and startups
            </p>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="outline" className="text-red-600 border-red-200 animate-pulse">
                🔴 LIVE
              </Badge>
              <Badge variant="outline" className="text-blue-600 border-blue-200">
                ⚡ Ultra-Fast Updates Every 15s
              </Badge>
              <Badge variant="outline" className={`${getStatusColor()} font-medium`}>
                <Activity className="w-3 h-3 mr-1" />
                {systemStatus.toUpperCase()}
              </Badge>
            </div>
          </div>
          <div className="flex items-center gap-3 w-full lg:w-auto">
            <div className="hidden lg:block">
              <Badge variant="outline" className="text-gray-600 border-gray-200 px-4 py-2 text-sm flex items-center shadow-sm">
                <Newspaper className="w-4 h-4 mr-2 text-gray-500" />
                Total News: <span className="font-bold ml-1.5 text-gray-800">{totalArticleCount}</span>
              </Badge>
            </div>
            <div className="hidden lg:block">
              <Badge variant="outline" className="text-purple-600 border-purple-200 px-3 py-2 text-xs">
                Last Update: {lastUpdateTime.toLocaleTimeString('en-IN')}
              </Badge>
            </div>
            <div className="hidden lg:block">
              <NotificationCenter />
            </div>
            <Button 
              onClick={fetchLatestNews}
              disabled={refreshing}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 w-full lg:w-auto"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              {refreshing ? "Fetching News..." : "Manual Refresh"}
            </Button>
          </div>
        </div>

        {/* System Error Banner */}
        {error && articles.length > 0 && (
          <Alert className="mb-6 bg-red-50 border-red-200">
            <AlertTriangle className="h-4 w-4 text-red-700" />
            <AlertTitle className="text-red-800">System Alert</AlertTitle>
            <AlertDescription className="text-red-700">
              {error}
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setError(null)} 
                className="ml-2 h-auto p-0 text-red-700 underline"
              >
                Dismiss
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Email Verification Banner */}
        {user && !user.email_verified && (
          <Alert className="mb-6 bg-yellow-50 border-yellow-200">
            <Info className="h-4 w-4 text-yellow-700" />
            <AlertTitle className="text-yellow-800">Verify Your Email</AlertTitle>
            <AlertDescription className="text-yellow-700">
              Please go to the <Link to={createPageUrl("Settings")} className="font-bold underline hover:text-yellow-900">Settings page</Link> to verify your email and enable notifications.
            </AlertDescription>
          </Alert>
        )}

        {/* Enhanced Breaking News Banner */}
        {breakingNews.length > 0 && (
          <div className="bg-gradient-to-r from-red-500 to-pink-600 text-white rounded-xl p-4 mb-6 shadow-lg overflow-hidden relative">
            <div className="absolute top-0 right-0 bg-red-600 text-xs px-2 py-1 rounded-bl-lg font-bold animate-pulse">
              🔴 LIVE
            </div>
            <style>{`
              @keyframes scroll-up {
                from { transform: translateY(0); }
                to { transform: translateY(-50%); }
              }
              .animate-scroll-up {
                animation: scroll-up linear infinite;
              }
              .group:hover .animate-scroll-up {
                animation-play-state: paused;
              }
            `}</style>
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-5 h-5 animate-pulse" />
              <span className="font-bold text-lg">🚨 BREAKING NEWS ({breakingNews.length})</span>
            </div>
            <div className="h-16 overflow-hidden relative group">
              <div 
                className="absolute top-0 left-0 w-full animate-scroll-up"
                style={{ animationDuration: `${Math.max(120, breakingNews.slice(0, 10).length * 15)}s` }}
              >
                {[...breakingNews, ...breakingNews].map((article, index) => (
                  <p key={`${article.id}-${index}`} className="text-sm py-1 truncate whitespace-nowrap">
                    🔥 {article.title} - {article.source}
                  </p>
                ))}
              </div>
            </div>
            <div className="text-xs opacity-80 mt-2">
              Ultra-Fast Updates: Every 15 seconds | Master System: Active | Last: {lastUpdateTime.toLocaleTimeString('en-IN')} IST
            </div>
          </div>
        )}

        {/* Filters */}
        <NewsFilters 
          activeCategory={activeCategory}
          onCategoryChange={handleCategoryChange}
          sortBy={sortBy}
          onSortChange={setSortBy}
          breakingCount={breakingCount}
          categoryCounts={categoryCounts}
          aiToolsCount={aiToolsCount}
          seoToolsCount={seoToolsCount}
        />

        {/* News Grid */}
        {filteredArticles.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-4xl">📰</span>
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">No articles found</h3>
            <p className="text-gray-500">The system is actively monitoring for new content...</p>
          </div>
        ) : (
          <>
            {/* Mobile View */}
            {isMobile ? (
              <div className="relative">
                <div className="flex justify-center mb-4">
                  <div className="flex gap-1">
                    {filteredArticles.slice(0, Math.min(filteredArticles.length, 10)).map((_, index) => (
                      <div
                        key={index}
                        className={`h-1 rounded-full transition-all duration-300 ${
                          index === currentCardIndex 
                            ? 'bg-purple-600 w-8' 
                            : index < currentCardIndex 
                              ? 'bg-purple-300 w-4' 
                              : 'bg-gray-200 w-4'
                        }`}
                      />
                    ))}
                  </div>
                </div>

                <div className="relative overflow-hidden">
                  <NewsCard
                    article={filteredArticles[currentCardIndex]}
                    isBookmarked={bookmarkedArticles.includes(filteredArticles[currentCardIndex]?.id)}
                    onBookmarkToggle={handleBookmarkToggle}
                  />
                </div>

                <div className="flex justify-center mt-6 gap-2">
                  <Button
                    onClick={() => handleCardSwipe('prev')}
                    disabled={currentCardIndex === 0}
                    variant="outline"
                    className="px-4 py-2 text-gray-600 rounded-full disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    ← Previous
                  </Button>
                  <span className="px-4 py-2 text-gray-600 font-medium flex items-center">
                    {currentCardIndex + 1} / {filteredArticles.length}
                  </span>
                  <Button
                    onClick={() => handleCardSwipe('next')}
                    disabled={currentCardIndex === filteredArticles.length - 1}
                    className="px-4 py-2 bg-purple-600 text-white rounded-full disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Next →
                  </Button>
                </div>
              </div>
            ) : (
              /* Desktop View */
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredArticles.map((article) => (
                  <NewsCard
                    key={article.id}
                    article={article}
                    isBookmarked={bookmarkedArticles.includes(article.id)}
                    onBookmarkToggle={handleBookmarkToggle}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
