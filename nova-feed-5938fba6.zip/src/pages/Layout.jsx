

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import {
  Bot,
  Zap,
  Rocket,
  Settings,
  Menu,
  X,
  LogOut,
  User as UserIcon,
  Wrench,
  Bookmark
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger
} from "@/components/ui/sidebar";
import NotificationCenter from "./components/notifications/NotificationCenter";
import AutoUpdater from "./components/common/AutoUpdater";
import AutoRefresh from "./components/common/AutoRefresh";
import PhoneNumberModal from "./components/auth/PhoneNumberModal";

const navigationItems = [
  {
    title: "AI News",
    url: createPageUrl("Dashboard"),
    icon: Bot,
    color: "text-purple-600"
  },
  {
    title: "AI Tools",
    url: createPageUrl("AITools"),
    icon: Wrench,
    color: "text-pink-600"
  },
  {
    title: "Technology",
    url: createPageUrl("Technology"),
    icon: Zap,
    color: "text-blue-600"
  },
  {
    title: "Startups",
    url: createPageUrl("Startups"),
    icon: Rocket,
    color: "text-green-600"
  },
  {
    title: "My Bookmarks",
    url: createPageUrl("Bookmarks"),
    icon: Bookmark,
    color: "text-yellow-600"
  },
  {
    title: "Settings",
    url: createPageUrl("Settings"),
    icon: Settings,
    color: "text-gray-600"
  }
];

const systemItems = [
    {
    title: "Get Backup",
    url: createPageUrl("BackupData"),
    icon: Wrench, // Using Wrench as a placeholder for a 'backup' icon
    color: "text-blue-600"
  }
]

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showPhoneModal, setShowPhoneModal] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    setLoading(true);
    setError(null);
    try {
      const userData = await User.me();
      setUser(userData);
      if (userData && !userData.phone_number) {
        setShowPhoneModal(true);
      }
    } catch (error) {
      console.log("User not logged in or session expired");
      setUser(null);
      setShowPhoneModal(false);
    }
    setLoading(false);
  };

  const handlePhoneUpdate = () => {
    setShowPhoneModal(false);
    loadUser();
  };

  const handleLogout = async () => {
    try {
      await User.logout();
      setUser(null);
      window.location.reload();
    } catch (error) {
      console.error("Logout error:", error);
      window.location.reload();
    }
  };

  const handleLogin = async () => {
    try {
      await User.loginWithRedirect(window.location.href);
    } catch (error) {
      console.error("Login error:", error);
      setError("Login failed. Please try again.");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-2xl mx-auto mb-6 flex items-center justify-center">
            <span className="text-2xl">❌</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Oops! Something went wrong</h1>
          <p className="text-gray-600 mb-6">{error}</p>
          <Button onClick={() => window.location.reload()} className="w-full">
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl mx-auto mb-6 flex items-center justify-center">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/796986a75_image.png"
              alt="All AI News Hub"
              className="w-12 h-12 object-contain"
              onError={(e) => {
                e.target.style.display = 'none';
                e.target.parentNode.innerHTML = '🧠';
              }}
            />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">All AI News Hub</h1>
          <p className="text-gray-600 mb-8">Stay ahead with the latest AI, technology, and startup news. Get hourly updates delivered to your inbox and WhatsApp.</p>
          
          <Button
            onClick={handleLogin}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-3 text-lg font-medium"
          >
            Get Started
          </Button>
          <p className="text-sm text-gray-500 mt-4">
            Sign in with Google to access your personalized news feed
          </p>
        </div>
      </div>
    );
  }

  if (showPhoneModal) {
    return <PhoneNumberModal onComplete={handlePhoneUpdate} user={user} />;
  }

  return (
    <>
      <AutoUpdater />
      <AutoRefresh />
      <SidebarProvider>
        <div className="min-h-screen flex w-full bg-gray-50">
          <Sidebar className="border-r border-gray-200 bg-white">
            <SidebarHeader className="border-b border-gray-100 p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/796986a75_image.png"
                    alt="All AI News Hub"
                    className="w-8 h-8 object-contain"
                    onError={(e) => {
                      e.target.style.display = 'none';
                      e.target.parentNode.innerHTML = '🧠';
                    }}
                  />
                </div>
                <div>
                  <h2 className="font-bold text-xl text-gray-900">All AI News Hub</h2>
                  <p className="text-sm text-gray-500">Latest Updates</p>
                </div>
              </div>
            </SidebarHeader>
            
            <SidebarContent className="flex min-h-0 flex-1 flex-col overflow-hidden">
              <div className="flex-1 overflow-y-auto px-3 py-4">
                <SidebarGroup>
                  <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
                    Categories
                  </SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu>
                      {navigationItems.map((item) => (
                        <SidebarMenuItem key={item.title}>
                          <SidebarMenuButton
                            asChild
                            className={`hover:bg-gray-50 transition-all duration-200 rounded-xl mb-1 ${
                              location.pathname === item.url ? 'bg-gray-100 shadow-sm' : ''
                            }`}
                          >
                            <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                              <item.icon className={`w-5 h-5 ${item.color}`} />
                              <span className="font-medium text-gray-700">{item.title}</span>
                              {item.title === "AI News" && (
                                <div className="w-2 h-2 bg-red-500 rounded-full ml-auto animate-pulse"></div>
                              )}
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      ))}
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
                
                <SidebarGroup className="mt-6">
                  <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
                    System
                  </SidebarGroupLabel>
                   <SidebarGroupContent>
                    <SidebarMenu>
                      {systemItems.map((item) => (
                        <SidebarMenuItem key={item.title}>
                          <SidebarMenuButton
                            asChild
                            className={`hover:bg-gray-50 transition-all duration-200 rounded-xl mb-1 ${
                              location.pathname === item.url ? 'bg-gray-100 shadow-sm' : ''
                            }`}
                          >
                            <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                              <item.icon className={`w-5 h-5 ${item.color}`} />
                              <span className="font-medium text-gray-700">{item.title}</span>
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      ))}
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>

                {/* Community Section */}
                <SidebarGroup className="mt-6">
                  <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
                    Join Our Community
                  </SidebarGroupLabel>
                  <SidebarGroupContent>
                    {/* Telegram Bot */}
                    <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-4 mb-4">
                      <div className="text-center space-y-3">
                        <div className="w-12 h-12 bg-blue-500 rounded-full mx-auto flex items-center justify-center">
                          <span className="text-white text-lg">🤖</span>
                        </div>
                        <div>
                          <h3 className="font-bold text-gray-900 text-sm">AI News Bot</h3>
                          <p className="text-xs text-gray-600 mt-1">Get instant AI news updates</p>
                        </div>
                        <Button 
                          onClick={() => window.open('https://t.me/allainewshubbot', '_blank')}
                          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white text-sm py-2 h-auto"
                        >
                          🚀 Join Bot
                        </Button>
                        <p className="text-xs text-gray-500">
                          @allainewshubbot
                        </p>
                      </div>
                    </div>

                    {/* YouTube Channel */}
                    <div className="bg-gradient-to-br from-red-50 to-pink-50 rounded-xl p-4">
                      <div className="text-center space-y-3">
                        <div className="w-12 h-12 bg-red-500 rounded-full mx-auto flex items-center justify-center">
                          <span className="text-white text-lg">📺</span>
                        </div>
                        <div>
                          <h3 className="font-bold text-gray-900 text-sm">YouTube Channel</h3>
                          <p className="text-xs text-gray-600 mt-1">Watch AI news videos & updates</p>
                        </div>
                        <Button 
                          onClick={() => window.open('https://www.youtube.com/@knowledgeHubAIandTechVideos', '_blank')}
                          className="w-full bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white text-sm py-2 h-auto"
                        >
                          📺 Subscribe
                        </Button>
                        <p className="text-xs text-gray-500 break-all">
                          @knowledgeHubAIandTechVideos
                        </p>
                      </div>
                    </div>
                  </SidebarGroupContent>
                </SidebarGroup>
              </div>
            </SidebarContent>

            <SidebarFooter className="border-t border-gray-100 p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
                  <UserIcon className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900 text-sm truncate">{user?.full_name || "User"}</p>
                  <p className="text-xs text-gray-500 truncate">{user?.email || "email@example.com"}</p>
                </div>
              </div>
              <Button
                variant="outline"
                onClick={handleLogout}
                className="w-full justify-start gap-2 text-gray-600 hover:text-gray-900"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </Button>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col overflow-hidden">
            <header className="bg-white border-gray-200 border-b px-6 py-4 flex items-center justify-between md:hidden">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="hover:bg-gray-100 p-2 rounded-lg transition-colors duration-200" />
                <h1 className="text-xl font-bold text-gray-900">All AI News Hub</h1>
              </div>
              <NotificationCenter />
            </header>

            <div className="flex-1 overflow-auto">
              {children}
            </div>
          </main>
        </div>
      </SidebarProvider>
    </>
  );
}

