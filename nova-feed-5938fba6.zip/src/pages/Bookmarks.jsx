import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { NewsArticle } from "@/api/entities";
import { AITool } from "@/api/entities";
import NewsCard from "../components/news/NewsCard";
import AIToolCard from "../components/aitools/AIToolCard";
import LoadingState from "../components/news/LoadingState";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Bookmark } from "lucide-react";

export default function Bookmarks() {
  const [loading, setLoading] = useState(true);
  const [bookmarkedArticles, setBookmarkedArticles] = useState([]);
  const [bookmarkedTools, setBookmarkedTools] = useState([]);
  const [userBookmarks, setUserBookmarks] = useState({ articles: [], tools: [] });

  useEffect(() => {
    loadBookmarks();
  }, []);

  const loadBookmarks = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      const articleIds = userData.bookmarked_articles || [];
      const toolIds = userData.bookmarked_tools || [];
      
      setUserBookmarks({ articles: articleIds, tools: toolIds });

      if (articleIds.length > 0) {
        const allArticles = await NewsArticle.list("-published_date", 500);
        const filteredArticles = allArticles.filter(article => articleIds.includes(article.id));
        setBookmarkedArticles(filteredArticles);
      } else {
        setBookmarkedArticles([]);
      }

      if (toolIds.length > 0) {
        const allTools = await AITool.list("-launch_date", 500);
        const filteredTools = allTools.filter(tool => toolIds.includes(tool.id));
        setBookmarkedTools(filteredTools);
      } else {
        setBookmarkedTools([]);
      }

    } catch (error) {
      console.error("Error loading bookmarks:", error);
    }
    setLoading(false);
  };

  const handleArticleBookmarkToggle = (articleId, isBookmarked) => {
    // If an item is un-bookmarked, remove it from the view instantly
    if (!isBookmarked) {
      setBookmarkedArticles(prev => prev.filter(a => a.id !== articleId));
    }
  };
  
  const handleToolBookmarkToggle = (toolId, isBookmarked) => {
    if (!isBookmarked) {
      setBookmarkedTools(prev => prev.filter(t => t.id !== toolId));
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <LoadingState />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center">
              <Bookmark className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">My Bookmarks</h1>
              <p className="text-gray-600">Your saved articles and tools</p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="news">
          <TabsList className="grid w-full grid-cols-2 md:w-96">
            <TabsTrigger value="news">
              Bookmarked News
              <Badge variant="secondary" className="ml-2">{bookmarkedArticles.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="tools">
              Bookmarked Tools
              <Badge variant="secondary" className="ml-2">{bookmarkedTools.length}</Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="news" className="mt-6">
            {bookmarkedArticles.length === 0 ? (
              <div className="text-center py-16 border-2 border-dashed rounded-lg">
                <Bookmark className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-xl font-medium text-gray-900">No bookmarked news</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Bookmark articles from the feed to see them here.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {bookmarkedArticles.map((article) => (
                  <NewsCard
                    key={article.id}
                    article={article}
                    isBookmarked={true} // Always true on this page
                    onBookmarkToggle={(id, isBookmarked) => handleArticleBookmarkToggle(id, isBookmarked)}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="tools" className="mt-6">
            {bookmarkedTools.length === 0 ? (
              <div className="text-center py-16 border-2 border-dashed rounded-lg">
                <Bookmark className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-xl font-medium text-gray-900">No bookmarked tools</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Find and bookmark tools to save them for later.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {bookmarkedTools.map((tool) => (
                  <AIToolCard
                    key={tool.id}
                    tool={tool}
                    isBookmarked={true} // Always true on this page
                    onBookmarkToggle={(id, isBookmarked) => handleToolBookmarkToggle(id, isBookmarked)}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}