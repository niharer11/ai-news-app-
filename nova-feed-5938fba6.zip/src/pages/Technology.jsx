import React, { useState, useEffect } from "react";
import { NewsArticle } from "@/api/entities";
import { User } from "@/api/entities";
import NewsCard from "../components/news/NewsCard";
import LoadingState from "../components/news/LoadingState";
import { Badge } from "@/components/ui/badge";
import { Zap } from "lucide-react";

export default function Technology() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [bookmarkedArticles, setBookmarkedArticles] = useState([]);

  useEffect(() => {
    loadTechNews();
  }, []);

  const loadTechNews = async () => {
    try {
      const userData = await User.me();
      setBookmarkedArticles(userData.bookmarked_articles || []);
      
      const techArticles = await NewsArticle.filter(
        { category: "technology" }, 
        "-published_date", 
        30
      );
      setArticles(techArticles);
    } catch (error) {
      console.error("Error loading tech news:", error);
    }
    setLoading(false);
  };

  const handleBookmarkToggle = (articleId, isBookmarked) => {
    if (isBookmarked) {
      setBookmarkedArticles(prev => [...prev, articleId]);
    } else {
      setBookmarkedArticles(prev => prev.filter(id => id !== articleId));
    }
  };

  if (loading) return <LoadingState />;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">Technology News</h1>
              <p className="text-gray-600">Latest updates from the tech world</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-blue-600 border-blue-200">
              ⚡ {articles.length} Tech Stories
            </Badge>
            <Badge variant="outline" className="text-gray-600">
              Updated hourly
            </Badge>
          </div>
        </div>

        {/* News Grid */}
        {articles.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-12 h-12 text-blue-600" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">No tech news yet</h3>
            <p className="text-gray-500">Check back soon for the latest technology updates</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article) => (
              <NewsCard
                key={article.id}
                article={article}
                isBookmarked={bookmarkedArticles.includes(article.id)}
                onBookmarkToggle={handleBookmarkToggle}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}